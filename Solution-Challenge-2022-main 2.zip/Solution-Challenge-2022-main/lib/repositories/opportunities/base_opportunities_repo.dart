abstract class BaseOpportunitiesRepo {}

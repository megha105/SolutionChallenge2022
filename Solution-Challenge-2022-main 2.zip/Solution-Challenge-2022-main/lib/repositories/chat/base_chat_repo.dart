abstract class BaseChatRepository {}

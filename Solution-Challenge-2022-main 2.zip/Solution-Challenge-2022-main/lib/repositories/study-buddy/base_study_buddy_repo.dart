abstract class BaseStudyBuddyRepo {}

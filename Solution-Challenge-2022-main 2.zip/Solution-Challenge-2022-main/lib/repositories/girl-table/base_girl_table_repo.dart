abstract class BaseGirlTableRepository {}

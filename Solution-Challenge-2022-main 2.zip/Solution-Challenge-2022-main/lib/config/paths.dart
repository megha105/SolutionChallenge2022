class Paths {
  static const String users = 'users';

  static const mentors = 'mentors';

  static const mentees = 'mentees';

  static const chats = 'chats';

  static const girlTtable = 'girlTable';

  static const discussion = 'discussion';

  static const discussionUsers = 'discussionUsers';

  static const discussionComments = 'discussionComments';

  static const studyBuddy = 'studyBuddy';

  static const studyGroups = 'studyGroups';

  static const studyGroupUsers = 'studyGroupUsers';

  static const opportunities = 'opportunities';

  // sub collection

  static const comments = 'comments';

  static const members = 'members';
}

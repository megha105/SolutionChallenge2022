enum NavItem { dashboard, mentorConnect, girlTable, profile }

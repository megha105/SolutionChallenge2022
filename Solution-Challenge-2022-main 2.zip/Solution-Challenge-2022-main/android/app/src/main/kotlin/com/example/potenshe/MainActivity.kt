package com.sixteenbrains.potenshe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

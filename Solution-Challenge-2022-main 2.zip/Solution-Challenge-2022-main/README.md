# POTENSHEIA
<img width="400" align='left' src="https://user-images.githubusercontent.com/72685035/161909863-6cb34cad-b599-4e92-b0e4-a4a21c61df94.png">

**INTRODUCTION : Unleah your inner potential to a unicorn career👩‍💻**
Right from childhood women face lot of struggles right from the time they are born, in rural areas people do not even consider educating or sending their daughters to higher studies. WHYYYYY??? See the potential every woman has in her, just be her support and witness the wonders she would do. 

“Human’s rights are women's rights and women's rights are human’s rights”.Let's make this world a better and more equal place for every individual. 

***Documentation:*** [Link](https://docs.google.com/document/d/1TK-mvsFH1qj0Nv7qaaki02S6XT8BXRd08VnmvbGh9Kc/edit?usp=sharing), 
***Demo:*** [Demo](https://www.youtube.com/watch?v=Oas0X-P1j1g)



- - - -
## Overview
POTENSHEIA is a mobile application designed to help women unleash their inner power to advance their skillset, rights, and opportunities for women around the globe. Our aim is to bridge the gender inequality gap and intersecting issues, connect with leaders around the world, and access opportunities in the area nearest to their location! Potensheia is an application specifically designed to steer young women from the ages of 12 towards both academic and professional careers in science, technology, engineering, and mathematics. 

##### Duration : 2022.03.04 ~ Present ⏰
- - - -
### Team member 💁🏻‍♀️💁🏻
#### Developer's : Ruchika Suryawanshi, Ruchi Pakhle, Rishi Kumar, Nishtha Sarawat 

- - - -
### Steps To Use Run This Project:
##### 1) Install Flutter.
##### 2) Install Dart.
##### 3) Clone this repo to desired location.
##### 4) Run Pub Get and Pub Upgrade.
##### 5) Run this Project on your android emulator or connect real device to check this out.
- - - - 
### Technology of Use 💻
####  Tools:-
1) Android Studio
2) Adobe XD

#### Google Technologies:-
1) Firebase
2) Cloud Firestore
3) Cloud Storage
4) Cloud Functions
5) Cloud Messaging
6) Google Cloud Platform(Dialog Flow)
7) Authentication
8) Play Console
9) Google Forms for taking surveys
10) Google Sheets for in app surveys
11) Google Translator
12) Google ML Kit
13) Google Teachable Machine
14) Google Maps

#### Languages:-
1) Flutter
2) Dart
3) JavaScript
- - -

- - -
